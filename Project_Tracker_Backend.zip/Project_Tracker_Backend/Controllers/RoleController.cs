using Microsoft.AspNetCore.Mvc;
using Project_Tracker_Backend.Data;
using Project_Tracker_Backend.Models;
using Microsoft.EntityFrameworkCore;
using Project_Tracker_Backend.DTOs;
using Project_Tracker_Backend.Comman;

namespace Project_Tracker_Backend.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly AppDbContext _context;

        public RoleController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var roles = await _context.Role
                .Select(r => new RoleReadDTO
                {
                    RoleId = r.RoleId,
                    RoleName = r.RoleName,
                    Description = r.Description
                }).ToListAsync();
            return Ok(new APIResponse<List<RoleReadDTO>>
            {
                Success = true,
                Message = "Get all roles successfully",
                Data = roles
            });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var role = await _context.Role
            .Where(r => r.RoleId == id)
            .Select(r => new RoleReadDTO
            {
                RoleId = r.RoleId,
                RoleName = r.RoleName,
                Description = r.Description
            })
            .FirstOrDefaultAsync();

            if (role == null)
                return NotFound();

            return Ok(role);
        }

        [HttpPost]
        public async Task<IActionResult> Add(RoleCreateDTO dto)
        {
            try
            {
                var role = new Role
                {
                    RoleName = dto.RoleName,
                    Description = dto.Description
                };

                _context.Role.Add(role);

                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetById), new { id = role.RoleId }, new APIResponse<Role>
                {
                    Success = true,
                    Message = "Role Added Successfully",
                    Data = role
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new APIResponse<Role>
                {
                    Success = false,
                    Message = "Error occurred while adding role",
                    Errors = new List<string> { ex.Message }
                });
            }
        }
    

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, RoleUpdateDTO dto)
        {
            try
            {
                var existingRole = await _context.Role.FindAsync(id);

                if (existingRole == null)
                    return NotFound();

                existingRole.RoleName = dto.RoleName;
                existingRole.Description = dto.Description;

                await _context.SaveChangesAsync();

                var result = new RoleReadDTO
                {
                    RoleId = existingRole.RoleId,
                    RoleName = existingRole.RoleName,
                    Description = existingRole.Description
                };

                return Ok(new APIResponse<RoleReadDTO>
                {
                    Success = true,
                    Message = "Role Updated Successfully",
                    Data = result
                });
            }
            catch(Exception ex)
            {
                return BadRequest(new APIResponse<RoleReadDTO>
                {
                    Success = false,
                    Message = "Error occurred while updating role",
                    Errors = new List<string> { ex.Message }
                });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var role = await _context.Role.FindAsync(id);
                if (role == null)
                {
                    return NotFound(new APIResponse<Role>
                    {
                        Success = false,
                        Message = "Role not found"
                    });
                }
                _context.Role.Remove(role);
                await _context.SaveChangesAsync();

                return Ok(new APIResponse<Role>
                {
                    Success = true,
                    Message = "Role deleted successfully"
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new APIResponse<object>
                {
                    Success = false,
                    Message = "Error occurred while deleting role",
                    Errors = new List<string> { ex.Message }
                });
            }
        }
    }
}

